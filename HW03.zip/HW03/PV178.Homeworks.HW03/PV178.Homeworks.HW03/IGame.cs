﻿namespace PV178.Homeworks.HW03
{
    /// <summary>
    /// Represents game.
    /// </summary>
    public interface IGame
    {
        /// <summary>
        /// Starts the game.
        /// </summary>
        void Run();
    }
}
